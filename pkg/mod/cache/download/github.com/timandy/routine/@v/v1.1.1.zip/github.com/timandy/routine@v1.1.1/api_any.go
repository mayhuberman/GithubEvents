//go:build !go1.18
// +build !go1.18

package routine

// any is an alias for interface{} and is equivalent to interface{} in all ways.
type any = interface{}
