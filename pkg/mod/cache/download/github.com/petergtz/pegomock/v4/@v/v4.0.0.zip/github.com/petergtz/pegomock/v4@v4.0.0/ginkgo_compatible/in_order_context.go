package mock

type InOrderContext = pegomock.InOrderContext
