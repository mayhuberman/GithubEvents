package mock

var OptionWithT = pegomock.WithT
