Thank you for your contribution to **Pegomock**.

Please make sure to open your PR against the `develop` branch.