package mock

var Whenever = pegomock.When
