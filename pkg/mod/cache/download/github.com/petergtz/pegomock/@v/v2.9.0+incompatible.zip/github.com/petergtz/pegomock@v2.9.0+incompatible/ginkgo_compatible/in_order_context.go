package mock

import "github.com/petergtz/pegomock"

type InOrderContext = pegomock.InOrderContext
