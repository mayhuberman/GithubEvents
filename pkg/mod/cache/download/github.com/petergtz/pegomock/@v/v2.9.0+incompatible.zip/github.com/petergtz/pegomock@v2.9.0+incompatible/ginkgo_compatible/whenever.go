package mock

import (
	"github.com/petergtz/pegomock"
)

var Whenever = pegomock.When
